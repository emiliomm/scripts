﻿#requires -Modules @{ ModuleName="PnP.PowerShell"; ModuleVersion="2.2.0" }

<#
.SYNOPSIS
Obtains the site templates connected to the site specified on the configuration
.DESCRIPTION
Downloads the template files associated with the sites following the configuration on configSource.json
.NOTES
Permissions needed:
Sharepoint:
Sites.FullControl.All
User.Read.All
Graph:
Group.Read.All

.EXAMPLE
Go where the get-template folder is located on the terminal. Ex:
cd "fullPath"

.\Get-Template.ps1
Connects to the tenant with the Azure App Permissions and gets the templates files specified in the configGet file

It can be specified the directory where the templates and theme folders are located, where the configuration files are and where the csv files with the exported information will be created

$templatesFolderPath = "C:\Templates"
$themesFolderPath = "C:\Themes"
$configFilePath = "C:\Config\config.json"
$configSiteAssetsFilePath = "C:\Config\configSiteAssets.json"
$configSourceFilePath = "C:\Config\configSource.json"
$configTargetFilePath = "C:\Config\configTarget.json"
$exportCsvSitesPath = "C:\Information\sites.csv"
$exportCsvUsersPath = "C:\Information\users.csv"

$hashArguments = @{
    TemplatesFolderPath      = $templatesFolderPath
    ThemesFolderPath         = $themesFolderPath
    ConfigFilePath           = $configFilePath
    ConfigSiteAssetsFilePath = $configSiteAssetsFilePath
    ConfigSourceFilePath     = $configSourceFilePath
    ConfigTargetFilePath     = $configTargetFilePath
    ExportCsvSitesPath       = $exportCsvSitesPath
    ExportCsvUsersPath       = $exportCsvUsersPath
}
.\Get-Template.ps1 @hashArguments

#>

[CmdletBinding()]
param(
    #Path where the templates files will be created
    [string] $TemplatesFolderPath = $(Join-Path -Path $PSScriptRoot -ChildPath "templates"),
    #Path where the themes files will be created
    [string] $ThemesFolderPath = $(Join-Path -Path $PSScriptRoot -ChildPath "themes"),
    #Path where the config file is located
    [string] $ConfigFilePath = $($(Join-Path -Path $PSScriptRoot -ChildPath "config") | Join-Path -ChildPath "config.json"),
    #Path where the config assets file is located
    [string] $ConfigSiteAssetsFilePath = $($(Join-Path -Path $PSScriptRoot -ChildPath "config") | Join-Path -ChildPath "configSiteAssets.json"),
    #Path where the config file with the source parameters is located
    [string] $ConfigSourceFilePath = $($(Join-Path -Path $PSScriptRoot -ChildPath "config") | Join-Path -ChildPath "configSource.json"),
    #Path where the config file with the target parameters is located
    [string] $ConfigTargetFilePath = $($(Join-Path -Path $PSScriptRoot -ChildPath "config") | Join-Path -ChildPath "configTarget.json"),
    #Path where the csv file with the site information will be created
    [string] $ExportCsvSitesPath = $($(Join-Path -Path $PSScriptRoot -ChildPath "information") | Join-Path -ChildPath "sites.csv"),
    #Path where the csv file with the users information will be created
    [string] $ExportCsvUsersPath = $($(Join-Path -Path $PSScriptRoot -ChildPath "information") | Join-Path -ChildPath "users.csv"),
    #Path where the csv file with the assets library information will be created
    [string] $ExportCsvAssetsLibraryPath = $($(Join-Path -Path $PSScriptRoot -ChildPath "information") | Join-Path -ChildPath "assetsLibrary.csv"),
    #csv separator used on the csv files
    [string] $CsvDelimeter = ";"
)

function Connect-Site {
    [CmdletBinding()]
    param (
        [string] $Url
    )
    
    if ($global:certificatePath -and $global:tenantId -and $global:clientId) {
        Connect-SiteWithCert -Url $Url
    }
    else {           
        Connect-PnPOnline -Url $Url -Interactive
    } 
}

function Connect-SiteWithCert {
    [CmdletBinding()]
    param (
        [string] $Url
    )
    
    Connect-PnPOnline -Url $Url -CertificatePath $global:certificatePath -Tenant $global:tenantId -ClientId $global:clientId
}

function Get-Sites {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]$SitesCsvPath,
        [ExportedPagesType] $ExportedPages,
        $configTarget
    )
    
    Connect-Site -Url $global:urlSite

    $orgSites = Get-PnPOrgNewsSite
    $homeSitesDetailed = Get-PnPHomeSite -Detailed    
    $themes = Get-PnPTenantTheme
    #format:  i.e. "sites/branding/logos"
    $siteAssets = Get-PnPOrgAssetsLibrary

    $cdnType = "Private"
    $cdnPublic = Get-PnPTenantCdnEnabled -CdnType Public
    if ($cdnPublic.Value) {
        $cdnType = "Public"
    }
    $configTarget.cdn = $cdnType

    $hashArguments = @{
        UrlHub            = $global:urlSite
        OrgSites          = $orgSites
        HomeSitesDetailed = $homeSitesDetailed
        Themes            = $themes     
        ExportedPages     = $ExportedPages
        GetHubInfo        = $true
    }
    $sitesInfo = Get-HubSites @hashArguments
    $sitesInfo | Sort-Object -Property isHub -Descending | Export-CSV -Delimiter $CsvDelimeter -Path $SitesCsvPath -NoTypeInformation -Encoding utf8BOM
    
    #save Organizational Assets Library Url with the full source url
    $orgAssetsLibraries = @() 
    $siteUri = [System.Uri]$global:urlSite
    foreach ($siteAsset in $siteAssets) {   
        if ($siteAsset.LibraryUrl) {     
            $orgAssetsLibrary = [PsCustomObject]@{
                url = $siteUri.Scheme + "://" + $siteUri.Host + "/" + $siteAsset.LibraryUrl.DecodedUrl
            }
            $orgAssetsLibraries += $orgAssetsLibrary
        }
    }
    if ($orgAssetsLibraries) {
        $orgAssetsLibraries | Export-CSV -Delimiter $CsvDelimeter -Path $ExportCsvAssetsLibraryPath -NoTypeInformation -Encoding utf8BOM
    }
    
    $configTarget | ConvertTo-Json -depth 10 | Out-File $ConfigTargetFilePath -Force
}

function Get-HubSites {
    [CmdletBinding()]
    param (     
        [Parameter(Mandatory)]$UrlHub,
        $OrgSites,
        $HomeSitesDetailed,   
        $Themes,
        [ExportedPagesType] $ExportedPages,
        $GetHubInfo = $false
    )
    
    Connect-Site -Url $UrlHub

    $sitesInfo = @()

    #Get hub
    $hubSite = Get-PnPHubSite -Identity $UrlHub
    #Get connected sites
    $sitesUrl = $hubSite | Get-PnPHubSiteChild
    if ($GetHubInfo) {
        $sitesUrl += $UrlHub
    }
    foreach ($siteUrl in $sitesUrl) {
        Write-Host "Obtaining info from $siteUrl"

        $site = Get-PnPTenantSite -Identity $siteUrl

        Write-Host "Obtaining info"

        $internalName = $site.Url.split('/')[-1]
        $templateSubfolder = Join-Path -Path $TemplatesFolderPath -ChildPath $internalName
            
        $name = $site.Title
        $lcid = $site.LocaleId
        $isHub = $site.IsHubSite
        $hubUrl = $hubSite.SiteUrl
        $isOrgNews = $OrgSites -contains $siteUrl
        $isHome = $HomeSitesDetailed.Url.ToLower().Contains($siteUrl.ToLower())

        $path = Join-Path -Path $templateSubfolder -ChildPath "$($internalName).xml"
        $tempPath = Join-Path -Path $templateSubfolder -ChildPath "$($internalName)Temp.xml"

        Write-Host "Obtaining themes"
        $siteTheme = "default"

        if ($isHub) {
            $siteWeb = Get-PnPWeb -Includes PrimaryColor
            $selectedTheme = $Themes | Where-Object { $_.Palette.themePrimary -eq $siteWeb.PrimaryColor }
            if ($selectedTheme.Count -eq 1) {
                Get-PnPTenantTheme -Name $selectedTheme.Name -AsJson | Out-File $(Join-Path -Path $ThemesFolderPath -ChildPath "$($selectedTheme.Name).json")
                $siteTheme = $selectedTheme.Name
            }
            else {
                Write-Warning -Message "Site does not have theme"
            }
        }

        Write-Host "Connecting to $siteUrl"
        Connect-Site -Url $siteUrl
        
        Write-Host "Exporting template"
        New-Item -Path $templateSubfolder -ItemType Directory -Force | Out-Null
        Get-PnPSiteTemplate -Configuration $ConfigFilePath -Out $path

        if (-not (Test-Path -LiteralPath $path)) {
            Write-Error -Message "Template for site $($siteUrl) located at $($path) could not be read, make sure it exists"
            $path = "NOT FOUND: PROBABLY THE USER/APP DOES NOT HAVE PERMISSION TO GET THE TEMPLATE"
        }
        else {
            $template = Read-PnPSiteTemplate -Path $path

            $pagesFiles = @() + $template.ClientSidePages
            $savedPagesFiles = @()
            if ($ExportedPages -ne [ExportedPagesType]::None) {
                Write-Host "Saving pages and site assets"

                #Save pages
                #Get the pages we want to save
                if ($ExportedPages -eq [ExportedPagesType]::All) {
                    $savedPagesFiles = $pagesFiles
                }
                else {
                    #[ExportedPagesType]::HomeOnly
                    $landingPageName = $template.WebSettings.WelcomePage.split('/')[-1]
                    $savedPagesFiles += $pagesFiles.where{ $_.PageName -match $landingPageName }

                    #[ExportedPagesType]::TemplateOnly
                    if ($ExportedPages -ne [ExportedPagesType]::HomeOnly) {
                        $savedPagesFiles += $pagesFiles.where{ $_.PromoteAsTemplate -eq $true }
                    }
                }

                #Add organizational assets library to be extracted if they are from the current site
                $pnpOrgAssetsLibrary = Get-PnPOrgAssetsLibrary
                if ($pnpOrgAssetsLibrary) {
                    $siteAssetsLibraries = ($pnpOrgAssetsLibrary)[0].OrgAssetsLibraries
                    foreach ($siteLibrary in $siteAssetsLibraries) {
                        $urlAssets = $siteLibrary.LibraryUrl.DecodedUrl
                        $listAssets = Get-PnPList | Where-Object { $_.Url -like "$urlAssets*" }
                        if ($listAssets -and $listAssets.Title) {
                            $newListAsset = @{
                                title        = $listAssets.Title
                                includeItems = $true
                                query        = @{      
                                    includeAttachments = $true
                                }        
                            }
                            $configSiteAssets.lists.lists += $newListAsset
                            $configSiteAssets | ConvertTo-Json -depth 10 | Out-File $ConfigSiteAssetsFilePath -Force
                        }
                    }
                }

                #Save the Site Assets folder
                Get-PnPSiteTemplate -Configuration $ConfigSiteAssetsFilePath -Out $tempPath
                $templateSiteAssets = Read-PnPSiteTemplate -Path $tempPath
                if ($templateSiteAssets.Files) {
                    foreach ($file in $templateSiteAssets.Files) {
                        $file.Properties.Clear()
                        $template.Files.Add($file)
                    }
                }
                Remove-Item $tempPath
            }

            $template.ClientSidePages.Clear()        
            foreach ($sitePage in $savedPagesFiles) {
                $template.ClientSidePages.Add($sitePage)
            }

            Write-Host "Saving tempate"
            Save-PnPSiteTemplate -Template $template -Out $path -Force

            if ($isHub -and $siteUrl -ne $UrlHub) {
                $hashArguments = @{
                    UrlHub            = $siteUrl
                    OrgSites          = $orgSites
                    HomeSitesDetailed = $HomeSitesDetailed
                    Themes            = $Themes
                    ExportedPages     = $ExportedPages
                }
                $sitesInfoChild = Get-HubSites @hashArguments
                $sitesInfo += $sitesInfoChild
            }  
        }

        $siteInfo = [PsCustomObject]@{
            name         = $name
            url          = $siteUrl
            isHub        = $isHub
            hubUrl       = $hubUrl
            lcid         = $lcid
            isOrgNews    = $isOrgNews
            isHome       = $isHome
            siteTheme    = $siteTheme
            templatePath = $path
            newUrl       = $global:targetRoot + $([System.Uri]$siteUrl).LocalPath
        }
        $sitesInfo += $siteInfo
    }
    return $sitesInfo
}

function Get-Users {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]$SitesFilePath,
        [Parameter(Mandatory)]$ExportCsvPath
    )

    [String[]]$users = @()
    $usersInfo = @()

    Write-Host "Getting users and groups from sites"

    $id = 1
    Import-Csv $SitesFilePath -Delimiter $CsvDelimeter -Encoding utf8BOM | Foreach-Object {

        if (-not (Test-Path -LiteralPath $_.templatePath)) {
            Write-Error -Message "Template for site $($url) located at $($_.templatePath) could not be read, make sure it exists"
        }
        else {
            $template = Read-PnPSiteTemplate -Path $_.templatePath        
            foreach ($user in $template.Security.AdditionalAdministrators) {
                $users += $user.Name
            }

            foreach ($user in $template.Security.AdditionalOwners) {
                $users += $user.Name
            }

            foreach ($user in $template.Security.AdditionalMembers) {
                $users += $user.Name
            }

            foreach ($user in $template.Security.AdditionalVisitors) {
                $users += $user.Name
            }

            if ($template.Lists) {
                foreach ($list in $template.Lists) {
                    foreach ($role in $list.Security.RoleAssignments) {
                        $users += $role.Principal
                    }
                }
            }

            $users = $users | Sort-Object -Unique 
            foreach ($user in $users) { 
                Connect-Site -Url $global:urlSite

                $getUser = $false

                #Everyone
                if ($user -like "*c:0(.s|true*") {
                    $type = "Group"
                    $sourceId = ""
                    $sourceName = "Everyone"
                    $getUser = $true
                }
                #Everyone except external users	
                elseif ($user -like "*c:0-.f|rolemanager|spo-grid-all-users/*") {
                    $type = "Group"
                    $sourceId = $user.split('/')[-1]
                    $sourceName = "Everyone except external users"
                    $getUser = $true
                }
                #Azure AD security group	
                elseif ($user -like "*c:0t.c|tenant|*") {
                    $type = "Group"
                    $sourceId = $user.split('|')[-1]
                    $userObject = Get-PnPAzureADGroup -Identity $sourceId
                    $sourceName = $userObject.DisplayName
                    $getUser = $true
                }
                #M365 Group
                elseif ($user -like "*c:0o.c|federateddirectoryclaimprovider|*") {
                    $type = "Group"
                    $sourceId = $user.split('|')[-1]
                    $group = Get-PnPMicrosoft365Group -Identity $sourceId
                    $sourceName = $group.DisplayName
                    $getUser = $true
                }
                #Sharepoint User
                elseif ($user -like "*i:0#.f|membership|*") {
                    Connect-Site -Url $_.url

                    $type = "User"
                    $sourceId = $user.split('|')[-1]
                    $userObject = Get-PnPUser -Identity $user
                    $sourceName = $userObject.Title
                    $getUser = $true
                }

                if ($getUser) {                    
                    $foundUsers = $usersInfo | Where-Object { $_.claimString -eq $user }
                    if ($foundUsers.Count -eq 0) {  
                        $sourceObject = [PsCustomObject]@{
                            id   = $sourceId
                            name = $sourceName 
                            type = $type 
                        }
                        $targetObject = ""
                        $userInfo = [PsCustomObject]@{
                            site         = $_.url
                            claimString  = $user
                            type         = $type 
                            sourceObject = $sourceObject 
                            targetObject = $targetObject               
                        }
                        $usersInfo += $userInfo
                        $id++
                    }
                }
            }
        }
    }

    Write-Host "Exporting to file $ExportCsvPath"
    $usersInfo  | Export-CSV -Path $ExportCsvPath -Delimiter $CsvDelimeter -NoTypeInformation -Encoding utf8BOM
}

$global:clientId = ""
$global:certificatePath = ""
$global:tenantId = ""
$global:urlSite = ""

# Initialize logging
$date = Get-Date -Format "yyyyMMddHHmmss"
$logPath = Join-Path -Path $PSScriptRoot -ChildPath "Logs"
$logTemplateName = Join-Path -Path $logPath -ChildPath "GetTemplate-LogTemplate-$date.txt"
$logName = Join-Path -Path $logPath -ChildPath "GetTemplate-LogGlobal-$date.txt"

Start-Transcript -Path $logName -UseMinimalHeader
Set-PnPTraceLog -On -LogFile $logTemplateName -Level Debug

Write-Host "START>>"

if (-not (Test-Path -LiteralPath $ConfigFilePath)) {
    Write-Error "Config file not found at $ConfigFilePath"
    return
}

if (-not (Test-Path -LiteralPath $ConfigSiteAssetsFilePath)) {
    Write-Error "Config file site assets not found at $ConfigSiteAssetsFilePath"
    return
}

if (-not (Test-Path -LiteralPath $ConfigSourceFilePath)) {
    Write-Error "Source config file parameters not found at $ConfigSourceFilePath"
    return
}

if (-not (Test-Path -LiteralPath $ConfigTargetFilePath)) {
    Write-Error "Target config file parameters not found at $ConfigTargetFilePath"
    return
}


$config = (Get-Content $ConfigSourceFilePath -Raw) | ConvertFrom-Json
$configTarget = (Get-Content $ConfigTargetFilePath -Raw) | ConvertFrom-Json

# Id of the application to connect with
$global:clientId = $config.clientId
# Directory path where the certificate file (.pfx) is located
$global:certificatePath = $config.certificatePath
# Id of the tenant to connect to
$global:tenantId = $config.tenantId
$global:urlSite = $config.urlSite

$global:targetRoot = $configTarget.targetRoot

#1. No pages are extracted
#2. Site landing page
#3. Page templates
#4. Regular content pages (news and site pages) (All)
enum ExportedPagesType {
    None = 1
    HomeOnly = 2
    TemplateOnly = 3
    All = 4
}

#Creating directories if not exist
if (-not (Test-Path -LiteralPath $TemplatesFolderPath)) {
    New-Item -Path $TemplatesFolderPath -ItemType Directory -Force | Out-Null
}

#Create directories if not exist
$sitesDir = Split-Path $ExportCsvSitesPath -Parent
$usersDir = Split-Path $ExportCsvUsersPath -Parent
if (-not (Test-Path -LiteralPath $sitesDir)) {
    New-Item -Path $sitesDir -ItemType Directory -Force | Out-Null
}

if (-not (Test-Path -LiteralPath $usersDir)) {
    New-Item -Path $usersDir -ItemType Directory -Force | Out-Null
}

if (-not (Test-Path -LiteralPath $ThemesFolderPath)) {
    New-Item -Path $ThemesFolderPath -ItemType Directory -Force | Out-Null
}

#Disconnect current connection, to make sure we are using the correct user each time
try {
    Disconnect-PnPOnline -ErrorAction SilentlyContinue
}
catch {
    #empty catch prevent output to console
}

$hashArguments = @{
    SitesCsvPath  = $ExportCsvSitesPath
    ExportedPages = $config.getPages
    ConfigTarget  = $configTarget
}
Get-Sites @hashArguments

Get-Users -SitesFilePath $ExportCsvSitesPath -ExportCsvPath $ExportCsvUsersPath

Disconnect-PnPOnline

Write-Host ">>END"
Set-PnPTraceLog -Off
Stop-Transcript