﻿#requires -Modules @{ ModuleName="PnP.PowerShell"; ModuleVersion="2.2.0" }

<#
.SYNOPSIS
Creates the sites specified on the files exported with the Get-Template script
.NOTES
Permissions needed when using an Ayure App:
Sharepoint:
Sites.FullControl.All
Access to the SharePoint Tenant Administration site

.EXAMPLE
Go where the get-template folder is located on the terminal. Ex:
cd "fullPath"

.\Apply-Template.ps1 
Connects to the tenant with the Azure App Permissions and default paths for the sites information

$sitesCsvPath = "C:\Sites"
$themesFolderPath = "C:\Themes"
$configTargetFilePath = "C:\Config\configTarget.json"
.\Apply-Template.ps1 -CsvPath $csvPath -SitesCsvPath {sitesCsvPath} -ThemesFolderPath $themesFolderPath -ConfigTargetFilePath $configTargetFilePath
Connects to the tenant with the Azure App Permissions and specified paths for the sites information

#>


[CmdletBinding()]
param(
    #path with the sites csv file
    [string] $SitesCsvPath = $($(Join-Path -Path $PSScriptRoot -ChildPath "information") | Join-Path -ChildPath "sites.csv"),
    #path with the sites csv file
    [string] $UsersCsvPath = $($(Join-Path -Path $PSScriptRoot -ChildPath "information") | Join-Path -ChildPath "users.csv"),
    #path with the sites csv file
    [string] $AssetsLibraryCsvPath = $($(Join-Path -Path $PSScriptRoot -ChildPath "information") | Join-Path -ChildPath "assetsLibrary.csv"),
    #directory with the theme files
    [string] $ThemesFolderPath = $(Join-Path -Path $PSScriptRoot -ChildPath "themes"),
    #path with the config parametes json file
    [string] $ConfigTargetFilePath = $($(Join-Path -Path $PSScriptRoot -ChildPath "config") | Join-Path -ChildPath "configTarget.json"),
    #csv separator used on the csv files
    [string] $CsvDelimeter = ";"
)

function Connect-Site {
    [CmdletBinding()]
    param (
        [string] $Url
    )
    
    if ($global:certificatePath -and $global:tenantId -and $global:clientId) {
        Connect-SiteWithCert -Url $Url
    }
    else {           
        Connect-PnPOnline -Url $Url -Interactive
    } 
}

function Connect-SiteWithCert {
    [CmdletBinding()]
    param (
        [string] $Url
    )

    Connect-PnPOnline -Url $Url -CertificatePath $global:certificatePath -Tenant $global:tenantId -ClientId $global:clientId
}

function Add-Sites {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)] $SitesConfig,
        [Parameter(Mandatory)][string]$Owner,
        $AssetsLibraryConfig
    )

    Connect-Site -Url $global:tenantAdminUrl

    Write-Host "Applying tenant themes"
    Get-ChildItem $ThemesFolderPath -Filter *.json | 
    Foreach-Object {
        Add-ThemeTenant -ThemeName $($_.BaseName) -ThemeFilePath $(Join-Path -Path $ThemesFolderPath -ChildPath $_.Name)
    }

    #Site Creation
    foreach ($site in $SitesConfig) {
        $hashArguments = @{
            Title = $site.name
            Url   = $site.newUrl
            Lcid  = $site.lcid
            Owner = $Owner
        }
        Add-NewSite @hashArguments
    }
    
    #Hub registration
    foreach ($site in $SitesConfig) {
        if ([System.Convert]::ToBoolean($site.isHub)) {
            $hashArguments = @{
                Url   = $site.newUrl
                Title = $site.name
            }
            Register-Hub @hashArguments
        }
    }

    #Hub association
    foreach ($site in $SitesConfig) {
        if ($site.hubUrl -and ($site.url -ne $site.hubUrl)) {
            Write-Host "Associating hub with old url $($site.hubUrl) to site $($site.newUrl)"
            #old url of hubUrl must be replaced by te new url
            $hubSite = $SitesConfig | Where-Object { $_.url -eq $site.hubUrl }
            if ($hubSite) {
                Add-PnPHubSiteAssociation -Site $site.newUrl -HubSite $hubSite.newUrl
            }
            else {
                Write-Warning -Message "Hub for site with old url ($($site.url)) and new url ($($site.newUrl)) not found. (Hub url: $($site.hubUrl))"
            }
        }
    }

    #We replace the users from the original site for the ones on the .csv file
    $users = Import-Csv $UsersCsvPath -Delimiter $CsvDelimeter -Encoding utf8BOM
    foreach ($site in $SitesConfig) {
        $templateFile = Get-Content $site.templatePath
        if ($templateFile) {
            Write-Host "Updating template file users from site $($site.newUrl), file located at $($site.templatePath)"      
            foreach ($user in $users) {
                $templateFile = $templateFile.Replace($user.claimString, $user.targetObject)
            }
            $templateFile | Set-Content $site.templatePath -Force
        }
        else {
            Write-Error -Message "Template for $($site.newUrl) located at $($site.templatePath) not found"
        }
    }


    foreach ($site in $SitesConfig) {
        Connect-Site -Url $site.newUrl
        Write-Host "Applying template: $($site.newUrl)"
        Invoke-PnPSiteTemplate -Path $site.templatePath -ClearNavigation

        if ($site.siteTheme -ne "default") {
            Set-Theme -Url $site.newUrl -ThemeFilePath $(Join-Path -Path $ThemesFolderPath -ChildPath "$($site.siteTheme).json")
        }

        if ($site.isOrgNews) {
            New-OrgNewsSite -Url $site.newUrl
        }

        foreach ($assetLibraryConfig in $AssetsLibraryConfig) {
            if ($assetLibraryConfig -and $assetLibraryConfig.url -and $assetLibraryConfig.url.Contains($site.url)) {    
                #replace source url with target url
                $assetLibraryConfig.url = $assetLibraryConfig.url.Replace($site.url, $site.newUrl)
                New-OrgAssetsLibrary -SiteUrl $site.newUrl -OrgAssetRelativeUrl $assetLibraryConfig.url -CdnType $global:cdn
            }
        }
    }
}

function Add-NewSite {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $Title,
        [Parameter(Mandatory)][string] $Url,
        [Parameter(Mandatory)][string] $Owner,
        [string] $Lcid,
        [string] $HubSiteId
    )

    Write-Host "Creating site $Url"
    Connect-Site -Url $global:tenantAdminUrl

    if ($HubSiteId) {       
        New-PnPSite -Type CommunicationSite -Title $Title -Url $Url -Lcid $Lcid -Owner $Owner -HubSiteId $HubSiteId -Wait
    }
    else {        
        New-PnPSite -Type CommunicationSite -Title $Title -Url $Url -Lcid $Lcid -Owner $Owner -Wait
    }
}

function Add-ThemeTenant {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $ThemeName,
        [Parameter(Mandatory)][string] $ThemeFilePath
    )

    Write-Host "Adding following theme to tenant: '$ThemeFilePath'"
    $theme = (Get-Content $ThemeFilePath -Raw) | ConvertFrom-Json -AsHashtable
    Add-PnPTenantTheme -Identity  $ThemeName -Palette $theme -IsInverted $false -Overwrite
    Write-Host "Theme added"
}

function Register-Hub {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $Url,
        [Parameter(Mandatory)][string] $Title
    )

    Write-Host "Registering hub $Url"
    Register-PnPHubSite -Site $Url
    Set-PnPHubSite -Identity $Url -Title $Title -EnablePermissionsSync
    
}
function Set-Theme {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $Url,
        [Parameter(Mandatory)][string] $ThemeFilePath
    )

    Write-Host "Setting theme from file $ThemeFilePath"

    Connect-Site -Url $Url
    $themeFile = Get-Item $ThemeFilePath
    Set-PnPWebTheme -Theme $themeFile.BaseName
}

function New-OrgNewsSite {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $Url
    )

    Write-Host "Setting as organization news source $Url"

    Connect-Site -Url $global:tenantAdminUrl
    Add-PnPOrgNewsSite -OrgNewsSiteUrl $Url
}

#The organization asset libraries can only exist in one site of the tenant.
#Because of that, if an organization assets library already exists on the tenant, the command will fail.
function New-OrgAssetsLibrary {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string] $SiteUrl,
        [Parameter(Mandatory)][string] $OrgAssetRelativeUrl,
        $CdnType = "Private"
    )

    Connect-Site -Url $global:tenantAdminUrl

    $cdnPublic = Get-PnPTenantCdnEnabled -CdnType Public    
    $cdnPrivate = Get-PnPTenantCdnEnabled -CdnType Private
    if ($cdnPublic.Value -or $cdnPrivate.Value) {
        Write-Host "CDN already enabled on tenant, skipping step (Public: $($cdnPublic.Value)) (Private: $($cdnPrivate.Value))"
    }
    else {
        Write-Host "Enabling CDN of type $CdnType on tenant"
        Set-PnPTenantCdnEnabled -CdnType $CdnType -Enable $true
    }

    Write-Host "Breaking permission inheritance of the List $OrgAssetRelativeUrl"

    Connect-Site -Url $SiteUrl
    $list = Get-PnPList -Identity $OrgAssetRelativeUrl
    Set-PnPList -Identity $list -BreakRoleInheritance -CopyRoleAssignments

    Write-Host "Grant permission on List to All Users except external"

    $LoginName = "c:0-.f|rolemanager|spo-grid-all-users/$global:tenantId"

    #Set Permissions to read
    if ($Lcid -eq "1031") {
        Set-PnPListPermission -Identity $list -AddRole "Lesen" -User $LoginName
    }
    else {
        Set-PnPListPermission -Identity $list -AddRole "Read" -User $LoginName
    }
    
    $libraryUrl = Join-Path -Path $SiteUrl -ChildPath $OrgAssetRelativeUrl
    Write-Host "Adding the document library as organizational asset source $libraryUrl"
    Add-PnPOrgAssetsLibrary -LibraryUrl $libraryUrl
}

$global:tenantAdminUrl = ""
$global:clientId = ""
$global:certificatePath = ""
$global:tenantId = ""

# Initialize logging
$date = Get-Date -Format "yyyyMMddHHmmss"
$logPath = Join-Path -Path $PSScriptRoot -ChildPath "Logs"
$logTemplateName = Join-Path -Path $logPath -ChildPath "ApplyTemplate-LogTemplate-$date.txt"
$logName = Join-Path -Path $logPath -ChildPath "ApplyTemplate-LogGlobal-$date.txt"

Start-Transcript -Path $logName -UseMinimalHeader
Set-PnPTraceLog -On -LogFile $logTemplateName -Level Debug

Write-Host "START>>"
$config = (Get-Content $ConfigTargetFilePath -Raw) | ConvertFrom-Json

# Id of the application to connect with
$global:clientId = $config.clientId
# Directory path where the certificate file (.pfx) is located
$global:certificatePath = $config.certificatePath
# Id of the tenant to connect to
$global:tenantId = $config.tenantId
$global:tenantAdminUrl = $config.adminCenterUrl

$global:cdn = $config.cdn

#Disconnect current connection, to make sure we are using the correct user each time
try {
    Disconnect-PnPOnline -ErrorAction SilentlyContinue
}
catch {
    #empty catch prevent output to console
}

$sites = Import-Csv $SitesCsvPath -Delimiter $CsvDelimeter -Encoding utf8BOM
$assetsLibrary = Import-Csv $AssetsLibraryCsvPath -Delimiter $CsvDelimeter -Encoding utf8BOM
$sites = $sites | Sort-Object -property isHub -Descending
$hashArguments = @{
    SitesConfig         = $sites
    Owner               = $config.owner
    AssetsLibraryConfig = $assetsLibrary
}
Add-Sites @hashArguments

Disconnect-PnPOnline

Write-Host ">>END"
Set-PnPTraceLog -Off
Stop-Transcript